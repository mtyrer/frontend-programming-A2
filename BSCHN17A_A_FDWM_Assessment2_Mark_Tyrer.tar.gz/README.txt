<!--
* Author: Mark Tyrer
* Assignment: FDWM Recreate a Technology Web Page
* Student ID: 
* Student ID: STU-00001347
* Date: 10th of July, 2017
-->

This archive contains the assessment 2 submission for front-end development for web and mobile entitled "Recreate a Technology Web Page"

The files have also been uploaded to the site:
http://site265.digitalskillsacademy.me/


